package projeto.exceptions;

public class ClasseComItensAssociadosException extends Exception {
    public ClasseComItensAssociadosException(String msg) {super(msg);}
}
