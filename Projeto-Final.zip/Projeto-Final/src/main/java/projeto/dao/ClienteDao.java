package projeto.dao;

import projeto.model.Cliente;

public interface ClienteDao extends DaoGenerico<Cliente>{
}
