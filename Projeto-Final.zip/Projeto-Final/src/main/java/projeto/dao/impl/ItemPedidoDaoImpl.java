package projeto.dao.impl;

import projeto.dao.ItemPedidoDao;
import projeto.model.ItemPedido;

public class ItemPedidoDaoImpl extends DaoGenericoImpl<ItemPedido> implements ItemPedidoDao {
}
