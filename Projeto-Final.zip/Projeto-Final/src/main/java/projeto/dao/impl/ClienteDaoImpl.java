package projeto.dao.impl;

import projeto.dao.ClienteDao;
import projeto.model.Cliente;

public class ClienteDaoImpl extends DaoGenericoImpl<Cliente> implements ClienteDao {
}
