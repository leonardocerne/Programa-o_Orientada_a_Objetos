package projeto.dao;

import projeto.model.ItemPedido;

public interface ItemPedidoDao extends DaoGenerico<ItemPedido>{
}
